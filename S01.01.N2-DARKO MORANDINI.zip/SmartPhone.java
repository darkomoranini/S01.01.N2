
public class SmartPhone extends Telefono implements Camara, Reloj{

	public SmartPhone(String marca, String modelo) {
		super(marca, modelo);
		
	}
	
	@Override
	public void alarma() {
		System.out.println("Esta sonando la alarma");
		
	}

	@Override
	public void fotografiar() {
		System.out.println("Estas haciendo una foto");
		
	}
}
