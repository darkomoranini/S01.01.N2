
@FunctionalInterface
public interface Camara {

	public void fotografiar();
}
