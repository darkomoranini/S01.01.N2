
@FunctionalInterface
public interface Reloj {

	public void alarma();
}
