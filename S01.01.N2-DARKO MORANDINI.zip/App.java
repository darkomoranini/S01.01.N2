
public class App {

	public static void main(String[] Args) {
		
		SmartPhone smartphone = new SmartPhone("Iphone", "I10");
		
		System.out.println(smartphone.llamar(633253016));
		smartphone.alarma();
		smartphone.fotografiar();
	}
}
